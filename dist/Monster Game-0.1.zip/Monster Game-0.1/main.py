# -*- coding:utf-8 -*-
from Events import GameEvent

""" This Game is required the module 'numpy' """


def main():
    if __name__ == "__main__":
        o = GameEvent()
        o.run()


if __name__ == "__main__":
    main()
