from setuptools import setup, find_packages

setup(
    install_requires=[
        'numpy>=1.23.0'
    ],
    entry_points={
        'console_scripts': [
            'monster_game = MonsterGame.main:main'
        ]
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Win32 (MS Windows)",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11"
    ],
    name="Monster Game",
    version="0.01",
    author="Alvin.li",
    author_email="Alvin.li@harrowhaikou.cn",
    description="A simple monster game.",

    url="https://github.com/Alvin0412/Y10-Exam-Monster-game",
    packages=find_packages()
)
